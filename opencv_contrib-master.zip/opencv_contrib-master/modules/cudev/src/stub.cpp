#include <opencv2/core/cvdef.h>

namespace cv { namespace cudev {

CV_EXPORTS void stubFunc();

}}

void cv::cudev::stubFunc()
{
}
